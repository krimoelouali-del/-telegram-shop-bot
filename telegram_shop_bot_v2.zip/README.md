# Bot Telegram boutique — produits légaux

## Installation
1. Créer un bot avec @BotFather.
2. Copier `.env.example` vers `.env`.
3. Renseigner `BOT_TOKEN` avec le token BotFather.
4. Renseigner `ADMIN_IDS` avec ton identifiant Telegram.
5. Installer Python 3.11+.
6. `pip install -r requirements.txt`
7. `python bot.py`

## Menus
Client : Catalogue, panier, commandes, livraison, support, informations.
Admin : Ajouter, modifier, supprimer un produit, voir les commandes.

Le paiement réel n'est pas inclus dans cette base.
