import os
import sqlite3
from dotenv import load_dotenv
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application, CommandHandler, CallbackQueryHandler,
    MessageHandler, ContextTypes, filters, ConversationHandler
)

load_dotenv()
TOKEN = os.getenv("BOT_TOKEN", "")
ADMIN_IDS = {int(x.strip()) for x in os.getenv("ADMIN_IDS", "").split(",") if x.strip()}
DB = "shop.db"

ADD_NAME, ADD_PRICE, ADD_DESC = range(3)
EDIT_NAME, EDIT_PRICE, EDIT_DESC = range(3, 6)

def get_db():
    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    return con

def init_db():
    con = get_db()
    con.executescript("""
    CREATE TABLE IF NOT EXISTS products (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        price REAL NOT NULL,
        description TEXT DEFAULT ''
    );
    CREATE TABLE IF NOT EXISTS cart (
        user_id INTEGER NOT NULL,
        product_id INTEGER NOT NULL,
        qty INTEGER NOT NULL DEFAULT 1,
        PRIMARY KEY (user_id, product_id)
    );
    CREATE TABLE IF NOT EXISTS orders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        username TEXT,
        items TEXT NOT NULL,
        total REAL NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    """)
    con.commit()
    con.close()

def main_menu():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🛍️ Catalogue", callback_data="catalog")],
        [InlineKeyboardButton("🛒 Mon panier", callback_data="cart"),
         InlineKeyboardButton("📦 Mes commandes", callback_data="orders")],
        [InlineKeyboardButton("🚚 Livraison", callback_data="delivery"),
         InlineKeyboardButton("💬 Support", callback_data="support")],
        [InlineKeyboardButton("ℹ️ Informations", callback_data="info")]
    ])

def admin_menu():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("➕ Ajouter un produit", callback_data="admin_add")],
        [InlineKeyboardButton("✏️ Modifier un produit", callback_data="admin_edit")],
        [InlineKeyboardButton("🗑️ Supprimer un produit", callback_data="admin_delete")],
        [InlineKeyboardButton("📦 Voir les commandes", callback_data="admin_orders")]
    ])

def home_button():
    return InlineKeyboardMarkup([[InlineKeyboardButton("◀️ Menu principal", callback_data="home")]])

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "👋 Bienvenue !\n\nChoisis une option :", reply_markup=main_menu()
    )

async def admin(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id not in ADMIN_IDS:
        await update.message.reply_text("⛔ Accès refusé.")
        return
    await update.message.reply_text("🔐 Administration", reply_markup=admin_menu())

async def catalog(q):
    con = get_db()
    products = con.execute("SELECT * FROM products ORDER BY id DESC").fetchall()
    con.close()
    if not products:
        await q.edit_message_text("🛍️ Le catalogue est actuellement vide.", reply_markup=home_button())
        return
    buttons = [[InlineKeyboardButton(
        f"{p['name']} — {p['price']:.2f} €", callback_data=f"product:{p['id']}"
    )] for p in products]
    buttons.append([InlineKeyboardButton("◀️ Menu principal", callback_data="home")])
    await q.edit_message_text(
        "🛍️ **Catalogue**\n\nSélectionne un produit :",
        parse_mode="Markdown",
        reply_markup=InlineKeyboardMarkup(buttons)
    )

async def product(q, pid):
    con = get_db()
    p = con.execute("SELECT * FROM products WHERE id=?", (pid,)).fetchone()
    con.close()
    if not p:
        await q.answer("Produit introuvable.", show_alert=True)
        return
    await q.edit_message_text(
        f"**{p['name']}**\n\n{p['description'] or 'Aucune description.'}\n\n💶 **{p['price']:.2f} €**",
        parse_mode="Markdown",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("➕ Ajouter au panier", callback_data=f"add:{pid}")],
            [InlineKeyboardButton("◀️ Catalogue", callback_data="catalog")]
        ])
    )

async def cart(q, uid):
    con = get_db()
    rows = con.execute("""
        SELECT p.name, p.price, c.qty
        FROM cart c JOIN products p ON p.id=c.product_id
        WHERE c.user_id=?
    """, (uid,)).fetchall()
    con.close()
    if not rows:
        await q.edit_message_text("🛒 Ton panier est vide.", reply_markup=home_button())
        return
    total = sum(r["price"] * r["qty"] for r in rows)
    text = "🛒 **Mon panier**\n\n" + "\n".join(
        f"• {r['name']} × {r['qty']} — {r['price'] * r['qty']:.2f} €" for r in rows
    )
    text += f"\n\n**Total : {total:.2f} €**"
    await q.edit_message_text(
        text, parse_mode="Markdown",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("✅ Passer commande", callback_data="checkout")],
            [InlineKeyboardButton("◀️ Menu principal", callback_data="home")]
        ])
    )

async def user_orders(q, uid):
    con = get_db()
    orders = con.execute(
        "SELECT * FROM orders WHERE user_id=? ORDER BY id DESC", (uid,)
    ).fetchall()
    con.close()
    if not orders:
        text = "📦 Tu n'as aucune commande."
    else:
        text = "📦 **Mes commandes**\n\n" + "\n".join(
            f"#{o['id']} — {o['total']:.2f} € — {o['created_at']}" for o in orders
        )
    await q.edit_message_text(text, parse_mode="Markdown", reply_markup=home_button())

async def callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    data = q.data
    uid = q.from_user.id

    if data == "home":
        await q.edit_message_text("🏠 **Menu principal**", parse_mode="Markdown", reply_markup=main_menu())
    elif data == "catalog":
        await catalog(q)
    elif data.startswith("product:"):
        await product(q, int(data.split(":")[1]))
    elif data.startswith("add:"):
        pid = int(data.split(":")[1])
        con = get_db()
        exists = con.execute("SELECT id FROM products WHERE id=?", (pid,)).fetchone()
        if exists:
            con.execute("""
                INSERT INTO cart(user_id, product_id, qty) VALUES(?,?,1)
                ON CONFLICT(user_id, product_id) DO UPDATE SET qty=qty+1
            """, (uid, pid))
            con.commit()
        con.close()
        await q.edit_message_text(
            "✅ Produit ajouté au panier.",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🛒 Voir le panier", callback_data="cart")],
                [InlineKeyboardButton("🛍️ Continuer", callback_data="catalog")]
            ])
        )
    elif data == "cart":
        await cart(q, uid)
    elif data == "orders":
        await user_orders(q, uid)
    elif data == "checkout":
        con = get_db()
        rows = con.execute("""
            SELECT p.name, p.price, c.qty
            FROM cart c JOIN products p ON p.id=c.product_id
            WHERE c.user_id=?
        """, (uid,)).fetchall()
        if not rows:
            con.close()
            await q.edit_message_text("🛒 Ton panier est vide.", reply_markup=home_button())
            return
        total = sum(r["price"] * r["qty"] for r in rows)
        items = "; ".join(f"{r['name']} x{r['qty']}" for r in rows)
        con.execute(
            "INSERT INTO orders(user_id, username, items, total) VALUES(?,?,?,?)",
            (uid, q.from_user.username or "", items, total)
        )
        con.execute("DELETE FROM cart WHERE user_id=?", (uid,))
        con.commit()
        con.close()
        await q.edit_message_text(
            f"✅ **Commande enregistrée !**\n\nMontant : **{total:.2f} €**",
            parse_mode="Markdown", reply_markup=home_button()
        )
    elif data == "delivery":
        await q.edit_message_text(
            "🚚 **Livraison**\n\nAjoute ici les informations de livraison de ta boutique légale.",
            parse_mode="Markdown", reply_markup=home_button()
        )
    elif data == "support":
        await q.edit_message_text(
            "💬 **Support**\n\nAjoute ici le moyen de contact de ton support.",
            parse_mode="Markdown", reply_markup=home_button()
        )
    elif data == "info":
        await q.edit_message_text(
            "ℹ️ **Informations**\n\nCette boutique est destinée à des produits légaux.",
            parse_mode="Markdown", reply_markup=home_button()
        )

async def admin_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    if q.from_user.id not in ADMIN_IDS:
        return
    data = q.data

    if data == "admin_add":
        await q.message.reply_text("➕ Ajout d'un produit\n\nEnvoie le nom du produit :")
        context.user_data.clear()
        context.user_data["admin_flow"] = "add"
        return ADD_NAME

    if data in ("admin_edit", "admin_delete"):
        con = get_db()
        products = con.execute("SELECT * FROM products ORDER BY id").fetchall()
        con.close()
        if not products:
            await q.message.reply_text("Aucun produit.")
            return ConversationHandler.END
        prefix = "admin_edit_product:" if data == "admin_edit" else "admin_delete_product:"
        await q.message.reply_text(
            "Sélectionne un produit :",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton(f"{p['id']} — {p['name']}", callback_data=f"{prefix}{p['id']}")]
                for p in products
            ])
        )
        return ConversationHandler.END

    if data == "admin_orders":
        con = get_db()
        orders = con.execute("SELECT * FROM orders ORDER BY id DESC LIMIT 50").fetchall()
        con.close()
        if not orders:
            text = "📦 Aucune commande."
        else:
            text = "📦 **Commandes**\n\n" + "\n".join(
                f"#{o['id']} | @{o['username'] or '-'} | {o['total']:.2f} €\n{o['items']}\n{o['created_at']}"
                for o in orders
            )
        await q.message.reply_text(text, parse_mode="Markdown")

async def add_name(update, context):
    context.user_data["name"] = update.message.text.strip()
    await update.message.reply_text("Prix en euros (exemple : 19.90) :")
    return ADD_PRICE

async def add_price(update, context):
    try:
        price = float(update.message.text.replace(",", "."))
        if price < 0: raise ValueError
    except ValueError:
        await update.message.reply_text("❌ Prix invalide. Exemple : 19.90")
        return ADD_PRICE
    context.user_data["price"] = price
    await update.message.reply_text("Description du produit :")
    return ADD_DESC

async def add_desc(update, context):
    con = get_db()
    con.execute(
        "INSERT INTO products(name, price, description) VALUES(?,?,?)",
        (context.user_data["name"], context.user_data["price"], update.message.text.strip())
    )
    con.commit()
    con.close()
    await update.message.reply_text("✅ Produit ajouté avec succès.")
    return ConversationHandler.END

async def admin_edit_product(update, context):
    q = update.callback_query
    await q.answer()
    if q.from_user.id not in ADMIN_IDS:
        return
    pid = int(q.data.split(":")[1])
    con = get_db()
    p = con.execute("SELECT * FROM products WHERE id=?", (pid,)).fetchone()
    con.close()
    if not p:
        await q.message.reply_text("Produit introuvable.")
        return
    context.user_data.clear()
    context.user_data["edit_id"] = pid
    context.user_data["old_product"] = dict(p)
    await q.message.reply_text(f"✏️ Nouveau nom pour « {p['name']} » :")
    return EDIT_NAME

async def edit_name(update, context):
    context.user_data["new_name"] = update.message.text.strip()
    await update.message.reply_text("Nouveau prix en euros :")
    return EDIT_PRICE

async def edit_price(update, context):
    try:
        price = float(update.message.text.replace(",", "."))
        if price < 0: raise ValueError
    except ValueError:
        await update.message.reply_text("❌ Prix invalide. Exemple : 19.90")
        return EDIT_PRICE
    context.user_data["new_price"] = price
    await update.message.reply_text("Nouvelle description :")
    return EDIT_DESC

async def edit_desc(update, context):
    con = get_db()
    con.execute(
        "UPDATE products SET name=?, price=?, description=? WHERE id=?",
        (context.user_data["new_name"], context.user_data["new_price"],
         update.message.text.strip(), context.user_data["edit_id"])
    )
    con.commit()
    con.close()
    await update.message.reply_text("✅ Produit modifié.")
    return ConversationHandler.END

async def admin_delete_product(update, context):
    q = update.callback_query
    await q.answer()
    if q.from_user.id not in ADMIN_IDS:
        return
    pid = int(q.data.split(":")[1])
    con = get_db()
    con.execute("DELETE FROM cart WHERE product_id=?", (pid,))
    con.execute("DELETE FROM products WHERE id=?", (pid,))
    con.commit()
    con.close()
    await q.message.reply_text("🗑️ Produit supprimé.")

def main():
    if not TOKEN:
        raise RuntimeError("BOT_TOKEN est manquant.")
    init_db()
    app = Application.builder().token(TOKEN).build()

    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("admin", admin))

    add_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(admin_callback, pattern=r"^admin_add$")],
        states={
            ADD_NAME: [MessageHandler(filters.TEXT & ~filters.COMMAND, add_name)],
            ADD_PRICE: [MessageHandler(filters.TEXT & ~filters.COMMAND, add_price)],
            ADD_DESC: [MessageHandler(filters.TEXT & ~filters.COMMAND, add_desc)],
        },
        fallbacks=[],
        per_user=True,
        per_chat=True
    )
    edit_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(admin_edit_product, pattern=r"^admin_edit_product:\d+$")],
        states={
            EDIT_NAME: [MessageHandler(filters.TEXT & ~filters.COMMAND, edit_name)],
            EDIT_PRICE: [MessageHandler(filters.TEXT & ~filters.COMMAND, edit_price)],
            EDIT_DESC: [MessageHandler(filters.TEXT & ~filters.COMMAND, edit_desc)],
        },
        fallbacks=[],
        per_user=True,
        per_chat=True
    )

    app.add_handler(add_conv)
    app.add_handler(edit_conv)
    app.add_handler(CallbackQueryHandler(admin_callback, pattern=r"^admin_(edit|delete|orders)$"))
    app.add_handler(CallbackQueryHandler(admin_delete_product, pattern=r"^admin_delete_product:\d+$"))
    app.add_handler(CallbackQueryHandler(callback))

    app.run_polling()

if __name__ == "__main__":
    main()
